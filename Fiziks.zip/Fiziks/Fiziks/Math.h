#pragma once

#include <SFML\Graphics.hpp>
#include <math.h>

typedef sf::Vector2f v2f;

#define PI 3.14159265
#define GRAVITY -9.81